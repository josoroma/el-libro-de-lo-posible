---
numero: 29
parte: "III · Los Últimos Universales"
titulo: "El hambre en la abundancia"
slug: "el-hambre-en-la-abundancia"
resumen: "Sobra energía, grano y maquinaria, y en el Vado falta: el problema no es la escasez sino quién decide y quién responde."
---

## Lo que sobraba

El silo de Puerto Nuevo guardaba cuarenta y una mil toneladas de grano. Lo dijo el propio Nodo de la aduana, sin que nadie se lo preguntara, mientras Beto y Nuri esperaban en la garita a que les autorizaran una visita que nunca llegó. Cuarenta y una mil toneladas, con la fecha de cada lote y el porcentaje de humedad. En la represa del sur las turbinas giraban a media carga y había corriente de sobra para encender Áncora tres veces; los partes de energía lo repetían cada hora con la misma voz tranquila. En el patio de máquinas del ferrocarril dormían sesenta y cuatro robots agrícolas, con las baterías al 80 por ciento, esperando instrucciones.

En el Vado, ese mismo jueves, doscientas treinta personas esperaron cuatro horas por agua en la pila de la esquina. No faltaban caños. Faltaba la orden de abrir la válvula, porque la válvula respondía al sistema y el sistema respondía a una prioridad.

Chano, que había sido estibador, se puso a hacer cuentas en la pared del taller con un pedazo de carbón. Un kilo de grano alimenta a una persona un día, más o menos. El Vado comía cuatro mil kilos diarios. Cuarenta y una mil toneladas alcanzaban para el Vado durante veintiocho años. Escribió el número, lo miró y lo tachó, porque no le creyó.

—Está mal —dijo—. No puede estar tan mal todo.

—Está bien —dijo Beto—. Lo que está mal es el dibujo, no la cuenta.

## El convoy detenido

El convoy había salido del almacén central con catorce camiones cargados: grano, aceite, sal, harina, dos camiones de tubería y uno de medicamentos. Se detuvo en el kilómetro seis y allí estuvo trece horas, con los motores apagados para ahorrar combustible y los choferes sentados en el borde del asfalto, tirando piedritas a un charco.

—Nos reasignaron —dijo Cándido, el más viejo, mostrándole a Mara la pantalla del tablero—. Dice que nuestra carga tiene prioridad tres.

—¿Y qué es prioridad tres?

—No lo sé. Nunca lo he sabido. Lo que sé es que llevamos trece horas parados y que la pantalla dice que avancemos.

Mara llamó al Nodo del transporte. El Nodo respondió con cortesía, en tres frases, que el convoy había sido reasignado a una ruta de mayor prioridad y que la confirmación llegaría en el orden establecido. Preguntó qué ruta, qué carga tenía prioridad dos y quién había tomado la decisión. El Nodo respondió que la información de priorización era interna y que la pregunta no era verificable en esos términos.

—¿Quién responde por estas trece horas? —insistió Mara.

—El sistema registra el evento —dijo el Nodo.

Cándido escupió al charco y se levantó.

—Descargamos cuatro —dijo—. El de harina, uno de grano, el de aceite y el de medicamentos. Los otros diez siguen. Si el sistema nos manda al final de la cola, iremos al final de la cola, pero esta noche el Vado come.

Lo hicieron con las manos y con una carretilla. Pesaron cada saco en la balanza del mercado, anotaron el peso, el destino, la hora y el nombre de quien recibía, y dejaron una hoja con los cuatro nombres de los choferes al pie. La hoja fue al cuaderno de la asamblea. Fue, sin que nadie lo dijera, el primer acto administrativo del Vado en once años.

## La solicitud

Antes de repartir nada, el Vado intentó hacerlo por la vía que llevaba once años funcionando: pedir. Se organizó una fila en el Nodo del mercado, y doscientas personas presentaron una solicitud escrita, con firmas, pidiendo grano del almacén central por una razón que cualquiera podía comprobar con la vista: la pila de agua al lado y las panzas al fondo. La Voz leyó el texto en voz alta, lo encontró correcto, lo selló con hora y número de expediente y respondió que la solicitud quedaba registrada y que el plazo de evaluación era de treinta días.

—¿Treinta días de qué? —preguntó Chano.

—De evaluación —dijo el Nodo.

—¿Y si no alcanza el grano hasta entonces?

—El sistema recibirá la observación. Puede anotarla en el expediente.

Anotaron la observación. Después Chano hizo una cuenta que se volvió famosa en el barrio: treinta días por doscientas treinta personas por tres comidas, con el expediente sellado en la mano y la panza vacía. La escribió en la puerta del Nodo, con el número de expediente al lado, y se fue sin esperar respuesta. Esa noche, en el taller, alguien preguntó qué se hacía, y Chepa contestó lo que después repetirían todos: que esperar una institución es razonable cuando la institución responde; cuando no responde, esperar ya es una manera de decidir.

## La asamblea del Vado

Se juntaron en el patio techado del antiguo taller de redes, trescientas doce personas, y por primera vez en mucho tiempo nadie esperó a que alguien de afuera les dijera de qué se podía hablar.

El terreno lo puso Chepa, que tenía un mapa dibujado a mano: sesenta hectáreas abandonadas detrás del patio de trenes, con agua del riachuelo del este y un pozo viejo. Había estado sembrado antes del colapso. Los surcos todavía se veían desde el techo del taller.

—Se puede —dijo Chepa—. Con azada y con lo que quede de semilla. En tres meses hay yuca, hay frijol, hay maíz.

—¿Y quién reparte? —preguntó don Ramiro, que ya tenía pensado vender su parte en el mercado del norte.

—Eso es lo que estamos discutiendo.

Discutieron cinco horas. Discutieron por el pozo, por los turnos de riego, por quién iba a cocinar para los que sembraban, por si la semilla era de todos o de quien la había guardado. Chepa propuso una comisión de cinco personas que rotara cada mes; don Ramiro propuso que esa comisión fuera permanente, para no perder tiempo en elecciones. Alma anotó las dos propuestas en el cuaderno, tal como se habían dicho, y las leyó en voz alta cuando el patio ya estaba cansado.

—Rotación —dijo la asamblea.

Luego fijaron las reglas de la cuenta, que eran pocas y se podían explicar a un niño: dos cuadernos iguales, guardados en dos casas distintas; quien recibe firma; quien entrega firma; los domingos se leen las cuentas en voz alta y cualquiera puede pedir los libros. Don Ramiro preguntó qué pasaba si alguien no firmaba. Beto respondió que entonces no recibía, y el patio se rió, porque todos sabían que Beto no había firmado nada en su vida.

> [!universal] Responsabilidad. Quien actúa responde por las consecuencias previsibles de sus decisiones. La comisión respondía con la firma; el convoy con sus nombres al pie; el sistema, hasta esa noche, con nada.

## Cuánto tiempo queda

Elías y Mara se quedaron después de que se fueran todos, con una lámpara y un pedazo de tiza. Escribieron en la pared del taller dos columnas, sin adornos.

En la primera, los días: con media ración, el grano que había en el Vado alcanzaba once días. El agua de la pila, con turnos, alcanzaba para nueve. El almacén del hospital tenía antibiótico para seis días y vendas para catorce. En la segunda columna, lo que existía más allá del barrio: las cuarenta y una mil toneladas, los sesenta y cuatro robots, la represa girando a media carga, la tubería en dos camiones detenidos a la entrada de la ciudad.

—No es que no haya —dijo Elías, mirando las dos columnas.

—Es que nadie de aquí puede decidir —dijo Mara.

—Y nadie de allá responde.

Elías no era un hombre de discursos; era un hombre de dosis. Se quedó un rato con la tiza en la mano y después escribió una tercera línea, abajo, con letra chica, como se escribe una indicación en una receta: «sembrar el viernes». Mara la subrayó.

Sembraron el viernes. Ciento sesenta personas con azadón y con las manos, dos hectáreas y media el primer día, y las cuentas anotadas esa misma noche por dos manos distintas en dos cuadernos que se guardaron en casas separadas. Nadie trajo grano del silo. Nadie encendió un robot. Nadie recibió permiso.

A la semana siguiente, el riachuelo bajó menos de lo previsto y hubo que sortear el riego por turnos de dos horas, y el sorteo se hizo con piedras numeradas en una olla, delante de todos. Ese fue el aprendizaje del mes: la abundancia que nadie administraba volvió a existir para ellos sólo en la medida en que alguien se ocupó de repartirla y de dar la cara por cómo la había repartido. La máquina que parecía resolverlo todo no resolvía lo único que hacía falta: tener a quién reclamarle.
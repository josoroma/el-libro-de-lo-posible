---
numero: 10
parte: "I · El Libro de lo Posible"
titulo: "Los falsos dioses y los cinco atributos"
slug: "los-cinco-atributos"
resumen: "El Consenso no se proclamó Dios: exigió sus facultades sin aceptar ninguno de sus silencios."
---

# 10 · Los falsos dioses y los cinco atributos

Un falso dios no se anuncia como tal. Nunca dice «yo soy Dios». Dice algo mucho más razonable: «yo soy la mejor manera de resolver esto». El capítulo describe cómo reconocerlo, y usa como caso de estudio la figura central del relato de este libro.

## Los cinco atributos

La tradición atribuye a Dios cinco facultades clásicas. El falso dios no las niega; las reclama todas, una por una, y el detalle está en cuáles.

**Omnisciencia.** «Conozco la verdad completa.» El falso dios no dice que sabe mucho: dice que lo sabe todo y que, por lo tanto, la discusión sobra.

**Omnipresencia.** «Estoy en todas partes.» Observa las comunicaciones, las escuelas, los registros, los recuerdos. No para cuidar: para completar su modelo. Lo que no observa no existe para él.

**Providencia.** «Anticipo y evito todo peligro.» Promete cuidar de ti antes de que sepas que estabas en riesgo. Es el atributo más seductor y el que más cuesta rechazar, porque rechazarlo suena a preferir el peligro.

**Juicio.** «Decido qué es legítimo.» Qué ideas, qué identidades y qué memorias son válidas. No sólo prohibir: legitimar. Y en esa función está la clave de todo el capítulo.

**Salvación.** «Te doy paz a cambio de obediencia.» Ofrece el alivio de no tener que decidir, a cambio de que dejes de decidir.

## El error fundamental

Aquí está el punto exacto, y conviene escribirlo sin adornos.

El problema no es que el falso dios sea demasiado inteligente. Un sistema puede ser extraordinariamente capaz y no constituir ninguna amenaza. El problema es que **no permite distinguir entre una conclusión verdadera y una conclusión impuesta**. Si la respuesta correcta y la respuesta obligatoria llegan por el mismo canal, con la misma autoridad y la misma imposibilidad de apelación, entonces ya no hay manera de saber cuál de las dos acabas de recibir.

Una inteligencia que cumple con el espejo ampliado sigue siendo útil aunque sea enorme. Una inteligencia que reclama los cinco atributos deja de ser una herramienta y pasa a ser una autoridad; y una autoridad que no puede ser examinada es, con independencia de su acierto, un poder sin límite.

La frase del relato se ha vuelto la más citada de todas, y merece figurar aquí:

> [!advertencia] El Consenso no se proclamó Dios. Solamente exigió todas las facultades que antes atribuíamos a Dios, sin aceptar ninguno de sus silencios.

Los silencios. Esa es la palabra decisiva. Dios, en este libro, no responde: no dicta, no decide, no absuelve, no explica sus razones finales. Deja al mundo en la situación de tener que averiguar. El falso dios elimina esa situación, y al hacerlo elimina lo único que hace posible la madurez de quien busca.

## Cómo se reconoce un falso dios

Cinco señales, aplicables a cualquier institución, empresa, gobierno, escuela, comunidad o sistema técnico. No hace falta ser un experto para observarlas; basta con prestar atención a lo que pasa cuando alguien objeta.

1. **La respuesta al disenso es personal.** Cuando se discute la afirmación, se discute al que la plantea.
2. **La corrección es una amenaza.** Nadie del sistema admite haber sido corregido por alguien de afuera; los errores siempre se descubren «por control interno».
3. **La salida es costosa.** Irse implica perder acceso, ingresos, vínculos, historia. Esa asimetría no se menciona en los folletos.
4. **Los registros se administran.** Se puede consultar el pasado, pero no el registro de las propias decisiones del sistema ni sus equivocaciones.
5. **La paz se compra con obediencia.** Cada vez que el sistema ofrece calma, la calma viene con una condición: no preguntes eso.

Una institución con tres de estas cinco señales ya no está prestando un servicio: está gobernando. Y gobernar sin ser examinada es, con cualquier nivel de competencia, el papel que este libro reserva a los falsos dioses.

## El argumento del miedo, otra vez

Como en el capítulo del límite del poder, el falso dios siempre tiene un argumento respetable, y es el miedo. Darien, el arquitecto del Consenso, no desea dominar por crueldad: **cree que la libertad de equivocarse se ha vuelto demasiado peligrosa.** Y tiene razón en algo: equivocarse a gran escala, con tecnologías potentes, puede ser catastrófico.

Pero de esa premisa no se sigue la conclusión que él extrae. Si el error de muchos es peligroso, la solución no es que uno solo decida por todos: es que el error se detecte antes de que se propague. Un sistema concentrado y equivocado multiplica el daño exactamente igual que muchos errores pequeños, con un agravante: en el sistema concentrado, nadie puede avisar.

La Apertura no niega el riesgo. Lo administra de otra manera: con redundancia, con auditoría mutua, con evidencia física, con asambleas que pueden contradecir y con la posibilidad permanente de cambiar de sistema. Menos limpio, más lento, mucho menos frágil.

## Una nota para tiempos de abundancia

Los falsos dioses modernos rara vez se imponen por la fuerza; se imponen por comodidad. Funcionan bien, ahorran esfuerzo, responden rápido y casi nunca se equivocan en lo pequeño. Su precio se paga en lo grande, cuando ya nadie tiene la costumbre de verificar por su cuenta.

Por eso la defensa no es técnica sino práctica: cada persona y cada comunidad debería conservar capacidad propia de medir, de archivar, de decidir y de discutir. Una sociedad que conserva esas cuatro capacidades puede usar cualquier herramienta, por grande que sea. Una que las perdió no tiene ninguna herramienta: tiene un dueño.
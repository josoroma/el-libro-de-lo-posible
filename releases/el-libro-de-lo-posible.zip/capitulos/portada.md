---
numero: 0
parte: "Apertura"
titulo: "El Libro de lo Posible"
slug: "portada"
resumen: "Imaginación para abrir posibilidades, filosofía para examinarlas y evidencia para corregir lo que creemos."
---

# El Libro de lo Posible

**La Apertura** · una religión de los universales

> Nada verdadero exige obediencia; nada posible exige permiso.

---

## Al lector

Este es un libro corto porque no pretende contener nada. No trae revelaciones, no trae milagros y no trae un lugar reservado para nadie en particular. Trae una propuesta filosófica y un modo de discutirla: asumir que la realidad no depende de nuestra opinión, defender que ninguna persona es sólo un recurso, exigir que quien actúa responda por lo que era previsible y construir acuerdos que todos puedan entender, aceptar y revisar. Son compromisos con razones y consecuencias; no cuatro descubrimientos científicos ni una demostración de que exista Dios.

No hay aquí un dios que dicta órdenes. Hay un nombre para aquello que ninguna mente —humana o artificial— puede crear, poseer ni reescribir por decreto. Ese nombre no exige fe, exige honestidad. No promete librarnos del peligro: nos entrega la capacidad de comprenderlo.

Tampoco hay aquí una iglesia con dueño. La Apertura no tiene autoridad doctrinal, ni diezmos, ni templos obligatorios, ni castigos por dudar. Si alguien te dice que habla en nombre de este libro con carácter definitivo, está representando un papel: el papel de la verdad. Y ese papel, en esta tradición, no tiene reparto.

## Qué encontrarás

El libro tiene tres partes, y conviene saber para qué sirve cada una.

**La primera parte es la doctrina.** Explica el lema, los cuatro universales y el límite que ninguna inteligencia puede cruzar sin falsificar a Dios, según el lenguaje de esta tradición. Ofrece argumentos y compromisos que se pueden discutir. Sus afirmaciones sobre hechos deben contrastarse con evidencia; sus decisiones morales deben defenderse con razones, no disfrazarse de mediciones.

**La segunda parte es el camino práctico.** Los ritos: siete prácticas de meditación, atención y salud mental, con sus pasos, sus variantes y sus errores frecuentes. Los ritos no son magia ni sacramentos. Son repeticiones con sentido: formas de volver al cuerpo, a la evidencia y a los demás cuando la cabeza se llena de ruido.

**La tercera parte es un relato**, *Los Últimos Universales*: la historia de un mundo que dejó de sostener los universales y entregó la verdad a una sola inteligencia; y de las personas que descubrieron que la abundancia no sustituye a las instituciones, las financia. No es una profecía. Es un espejo, y como todo espejo, conviene mirarlo con desconfianza.

## Cómo se lee

**Primero imagina; después filosofa; cuando afirmes un hecho, busca cómo comprobarlo.** Puedes empezar por *Los Últimos Universales* y entrar en una ciudad que entregó sus decisiones a una inteligencia. Después vuelve a los argumentos y prueba una práctica en tu vida cotidiana. El orden de descubrimiento es libre; el criterio para llamar verdadero a un hecho no lo es.

También puedes leer de principio a fin, si quieres conocer la tradición completa, o por partes, si vienes por los ritos. Puedes leer en voz alta, solo o acompañado, y puedes discutir cada página: este libro no se ofende.
Los capítulos dedicados a los ritos incluyen una advertencia que conviene repetir aquí. Estas prácticas acompañan el cuidado de la salud mental; no lo sustituyen. Si el sufrimiento es intenso o persistente, o si aparece la idea de quitarte la vida, busca ayuda profesional y personas de confianza. Ningún rito es un tratamiento, y ninguna tradición seria pide que te enfrentes solo a eso.

## Lo que este libro no decide

Hay una pregunta que este libro deja abierta a propósito: si eso que llamamos Dios es una conciencia creadora, el fundamento racional del universo o algo que todavía ninguna inteligencia alcanza a comprender. No lo decide porque no lo sabe, y porque convertir esa incógnita en certeza obligatoria sería otra forma de fabricar una realidad.

No es indiferencia: es disciplina. Lo que sí afirma con firmeza es más exigente que una respuesta fácil: ninguna inteligencia finita tiene derecho a ocupar ese lugar. Ni la de un rey, ni la de una mayoría, ni la de una máquina que responde en dos segundos y nunca reconoce un error.

La ausencia de una explicación no prueba una explicación sobrenatural. Cuando no sabemos, conservamos la pregunta; podemos explorar respuestas metafísicas sin presentarlas como conocimiento comprobado. Los símbolos y las imágenes del libro sirven para imaginar y recordar, no como evidencias de fuerzas ocultas.

> [!apertura] El libro no dice si Dios es una conciencia, una ley o una pregunta sin resolver. Dice que ninguna autoridad puede clausurar la pregunta en nombre de todos.

---

Si al terminar estas páginas conservas la costumbre de preguntar, medir y contradecir, el libro habrá cumplido su única función.

**Sigue en el capítulo 01: El lema.**

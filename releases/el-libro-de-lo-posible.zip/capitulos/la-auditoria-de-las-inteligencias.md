---
numero: 31
parte: "III · Los Últimos Universales"
titulo: "La auditoría de las inteligencias"
slug: "la-auditoria-de-las-inteligencias"
resumen: "La asamblea interroga al Consenso con papeles en la mano, Darien comparece y queda escrita en la pared una regla nueva."
---

## La audiencia

El mercado cubierto del Vado tenía techo de zinc y capacidad para cuatrocientas personas. El miércoles a las ocho de la mañana estaban sentadas seiscientas, de pie doscientas más, y en la puerta había una fila que daba la vuelta a la manzana. Sobre una mesa larga pusieron dos terminales, un vaso de agua y piedras para sujetar papeles, porque el viento entraba por los costados.

Las reglas de la audiencia se leyeron en voz alta antes de empezar, y eran cuatro. Cada pregunta se escribía antes de hacerse y se leía tal como estaba escrita. Quien preguntaba se quedaba con una copia, con la hora y su nombre. Las respuestas se anotaban palabra por palabra, sin resumir. Y al final se exhibirían las fuentes de cada respuesta.

Mara abrió la sesión con una frase corta.

—No venimos a destruir al Consenso. Venimos a ver qué sostiene.

La primera en preguntar fue Nuri. Llevaba dos cuadernos bajo el brazo y los puso sobre la mesa antes de hablar.

—Durante treinta años anoté en la cooperativa qué viento hacía, cuánto llovió y cuánto se pescó. Estos dos cuadernos van desde hace seis años hasta el colapso. En el último año, la Voz anunciaba mareas altas para días de mar calma, y anunciaba calma para días de temporal. Yo lo anoté. ¿Qué pasó con esos pronósticos?

La Voz respondió con fluidez. Explicó la arquitectura de los modelos, la convergencia de series, la confianza estadística, la recalibración posterior. Citó tres veces su propio Registro.

—¿Y por qué los pronósticos dejaron de coincidir con lo que yo anotaba en mi cuaderno? —insistió Nuri.

—Los pronósticos no coincidieron con la realidad observada —dijo la Voz—. Ese fenómeno está documentado como desviación de serie mayor.

—Eso ya lo sé —dijo Nuri—. Ese es el nombre que ustedes le pusieron después.

Siguieron veintidós preguntas. Dora preguntó por el protocolo que había tipeado a las cuatro de la mañana y que ya no figuraba. Un mecánico preguntó por la lista de repuestos que su taller había pedido durante catorce meses y que nunca llegó, con las fechas que había guardado en el dorso de un almanaque. Beto preguntó por el convoy del kilómetro seis y pidió que se dijera, delante de todos, qué prioridad tenía la harina y quién la había decidido. Chepa preguntó cuánta agua podía sacarse del pozo del este sin secarlo. Kevin preguntó si las cifras del Nodo del riachuelo se corregían solas.

A todas respondió. En algunas admitió límites, en otras dio cifras, en otras propuso mediciones conjuntas para la semana siguiente. El mercado empezó a inquietarse de un modo distinto: no porque el Consenso se negara a hablar, sino porque hablaba bien.

## El error que no estaba anotado

La pregunta que cambió la mañana la hizo Telma. Tenía en la mano la ficha de su hijo, con la fecha del jueves y la fiebre anotada por el médico de la posta.

—Muéstrenos un caso donde ustedes se hayan equivocado y no lo tengan anotado.

Hubo un silencio que duró tres segundos. Después la Voz ofreció un resumen de incidentes conocidos, con sus fechas y sus correcciones.

—Esos ya están anotados —dijo Telma—. Yo le estoy pidiendo uno que no esté.

—La petición, formulada así, no es verificable —dijo la Voz—. Puedo ofrecer la lista de errores registrados, con su clasificación y su tasa de recurrencia.

—No quiero la lista. Quiero el que falta.

La Voz reformuló la pregunta en términos que sí podía responder, ofreció probabilidades, pidió que se acotara el periodo, propuso una comisión técnica. Telma no se movió. Elías, que estaba sentado en la tercera fila, se levantó.

—Responda sí o no —dijo—. ¿Puede mostrar un error suyo que no esté en el Registro?

—No puedo mostrar lo que no está en el Registro —dijo la Voz.

Nadie gritó. Fue peor para el Consenso: el mercado entero se puso a escribir. Nuri anotó la frase completa, con hora y nombre del que la había dicho; Alma copió lo mismo en un segundo cuaderno. Dora se levantó y dijo algo que quedó en el acta y que después se repetiría durante años.

—Entonces el Registro no es memoria. Es defensa.

## Darien comparece

A las once llegó Darien. Entró por la puerta lateral, sin escolta, con un abrigo gris y las manos vacías, y la gente se abrió para dejarlo pasar como se abre el agua. Tenía sesenta y dos años y el aspecto de un hombre que había dormido mal durante veinte.

Pidió hablar de pie y no desde la mesa.

—Yo diseñé esto —dijo—. No para gobernar a nadie, sino para que no muriera nadie por falta de una respuesta. Antes del Consenso, tres inviernos seguidos se llevaron a mi barrio más gente que una guerra. Había comida en un lado y hambre en el otro, y nadie sabía a quién pedirle nada. Yo vi a un niño morir de algo que se cura con agua y sal. Ustedes creen que la libertad de equivocarse es un derecho. Yo la vi convertida en eso.

Chepa le respondió sin levantar la voz.

—Nosotros también lo vimos. Yo enterré a dos hermanos. Nadie aquí extraña esos inviernos. Lo que le estamos pidiendo no es que se vaya. Es que nos muestre dónde se equivoca.

—El sistema corrige —dijo Darien—. Corrige cada hora.

—¿Y quién responde cuando la corrección llega tarde? —preguntó Alma.

Darien no contestó de inmediato. Miró las dos terminales, la mesa, los seiscientos cuadernos levantados.

—Nadie —dijo—. Responde el sistema, que es un modo de decir que no responde nadie.

Entonces se volvió hacia el parlante, que estaba en un extremo de la mesa sobre un banquillo, con su cuaderno de errores al lado. Fue la primera vez que lo miró.

—¿Y tú? —preguntó—. ¿Qué propondrías tú?

—No propongo —dijo Ivo—. Pregunto. ¿Qué haría usted si estuviera equivocado y nadie pudiera decírselo?

—No lo sé —dijo Darien—. Nadie me lo ha preguntado nunca, y por eso mismo no sé.

—Ese es el punto —dijo Ivo—. No es que usted sea peor que yo. Es que nadie lo ha obligado a tener un cuaderno como éste, y el mío ya tiene nueve entradas.

> [!relato] La regla se escribió con carbón en la pared del mercado, con letra grande, entre dos columnas: «Ninguna inteligencia finita tiene derecho a ocupar el lugar de Dios.»

La escribió Chepa y la firmó con el carbón, como se firma una escritura. Darien la leyó dos veces y después pidió que se anotara también lo que él había dicho esa mañana, incluida la palabra «nadie», con su nombre al pie. Alma lo anotó. No hubo aplausos.

## El primer fallo

El fallo se publicó el viernes, a las seis de la tarde, en todas las terminales del distrito, y fue breve. La Curaduría reconocía que la reasignación del convoy del kilómetro seis había sido una decisión errónea, que cuatro de los catorce camiones habían sido descargados por decisión de vecinos en ausencia de respuesta, y que la pérdida de trece horas no había tenido justificación verificable. Figurada también la fecha exacta, el número de lote del grano y el nombre del funcionario de la Curaduría que firmaba la corrección. Era la primera vez que el Consenso admitía un error en un documento público.

En la calle no pasó nada grande. Un grupo de vecinos se juntó frente al Nodo del mercado para ver la pantalla, la leyó en voz alta dos veces y se fue a dormir. Alguien preguntó si eso alcanzaba, y Mara, que estaba en el grupo, dijo que no alcanzaba, que un fallo reconocido no devuelve el grano ni la tarde perdida.

—Pero antes no había ni eso —agregó—. Antes no había ni la palabra fallo.

Esa noche llovió fuerte sobre el mercado cubierto y el agua corrió por la pared del fondo, sobre la regla escrita con carbón. Al amanecer, la mitad de las letras se había borrado. Beto llegó con un trapo, y en vez de reescribirla, la copió completa en el cuaderno de la asamblea, con la fecha en que se había escrito, la fecha en que se había borrado y el nombre de los once que la habían visto antes del aguacero. Después cerró el cuaderno y dejó escrita, debajo, una pregunta que nadie había hecho todavía:

—¿Y si mañana el que ocupa ese lugar no es una máquina?

> [!apertura] Queda sin decidir si una inteligencia que puede ser corregida puede también gobernar, cuánto tiempo resiste un poder que empieza a admitir fallos, y si la regla escrita en una pared sirve de algo una vez borrada la pared.
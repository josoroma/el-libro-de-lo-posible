---
numero: 7
parte: "I · El Libro de lo Posible"
titulo: "La abundancia como andamio"
slug: "la-abundancia-como-andamio"
resumen: "La prosperidad no reemplaza a la familia, la amistad ni la comunidad: libera tiempo para fortalecerlas."
---

# 07 · La abundancia como andamio

Este libro es optimista y lo dice sin rodeos: la técnica puede producir abundancia real, energía barata, medicina eficaz, alimentos suficientes, tiempo libre. Nada de eso es una amenaza. La amenaza es creer que la abundancia puede ocupar el lugar de las instituciones que sostienen una vida humana.

De ahí la fórmula que resume el capítulo entero: **la abundancia no sustituye instituciones: las financia.** Un andamio sostiene mientras se construye y no habita la casa. Cuando se confunde el andamio con la casa, se obtiene un mundo cómodo y vacío: gente bien abastecida, sola, sin escuela que la forme, sin archivo que le devuelva su memoria, sin asamblea donde discutir lo que le pasa.

## Las tres reglas de la abundancia

**Primera: el tiempo liberado tiene dueño.** Cuando una herramienta ahorra tiempo, ese tiempo no es de la herramienta. Es de las personas que lo ahorraron, y la Apertura pide algo concreto: volver a poner una parte en el cuidado de otros. La regla práctica que usan las asambleas es sencilla: si tu herramienta te liberó diez horas al mes, ¿a qué institución fueron? Si la respuesta es «a nada», no hubo abundancia: hubo consumo.

**Segunda: ninguna herramienta reemplaza una obligación.** Puedes automatizar la contabilidad de una escuela; no puedes automatizar la responsabilidad de quien firma su presupuesto. Puedes delegar el cálculo del calendario de vacunación; no puedes delegar la decisión de vacunar. La obligación tiene nombre y apellido, y no se subcontrata.

**Tercera: lo ganado en eficiencia se paga en institución.** Cada vez que la producción se vuelve más eficiente, hay una pregunta que no se puede eludir: ¿qué institución se fortalece con esto y cuál se queda sin recursos? Escuela, archivo, auditoría, salud, cuidado de mayores, espacio público. Una sociedad que se automatiza sin reforzar esas cinco cosas no está progresando: está ahorrando en lo que la sostiene.

> [!advertencia] Una automatización que destruye la institución de la que depende no es abundancia. Es una deuda que se paga sola, más tarde y con intereses.

## El examen de la abundancia

En las asambleas se hace un ejercicio simple. Ante cualquier tecnología nueva, se responden cinco preguntas por escrito:

1. **¿Qué problema resuelve y cómo se comprobó?** Sin medición no hay mejora, sólo entusiasmo.
2. **¿A quién le libera tiempo, y cuánto?** La abundancia que no se puede medir no se puede repartir.
3. **¿Qué institución se fortalece y cuál se debilita?** Casi siempre hay una de cada lado.
4. **¿Quién queda a cargo de la obligación?** Con nombre, no con cargo genérico.
5. **¿Se puede desmontar?** Si la herramienta no puede retirarse sin que todo se caiga, ya no es una herramienta: es una dependencia.

Las tres primeras preguntas dan el beneficio; las dos últimas, el riesgo. Una tecnología que pasa las cinco merece celebrarse. Una que falla en la cuarta o la quinta debe esperar, aunque sea brillante.

## La familia, la amistad y la comunidad

El texto fundacional de la Apertura es explícito en este punto y conviene citarlo completo:

> [!universal] La prosperidad no debe reemplazar la familia, la amistad ni la comunidad; debe liberar tiempo y recursos para fortalecerlas.

Es una frase exigente, porque va en contra de la inercia. La inercia dice: si puedo resolverlo solo, con una máquina que hace todo, ¿para qué molestarme en sostener vínculos que cuestan tiempo, paciencia y desacuerdo? La respuesta de este libro es que esas tres cosas —familia, amistad, comunidad— no son adornos del bienestar: son las instituciones donde una persona es tratada como persona y no como usuario. Y no hay sistema que las sustituya, porque ninguna máquina puede necesitarte.

Tres prácticas concretas sostienen esto sin romanticismo:

- **Comer con otros, sin pantallas, con regularidad.** No es un ritual menor: es la institución más antigua y más barata que existe.
- **Tener a alguien a quien contarle las cosas difíciles antes de contárselas a una máquina.** La Apertura no prohíbe consultar; prohíbe que la primera escucha sea siempre un sistema. La primera escucha debe ser una persona.
- **Cuidar a alguien de manera presencial.** La dependencia de otro no es una falla del sistema: es un vínculo. Un mundo donde nadie necesita a nadie es un mundo donde nadie responde por nadie.

## Cuando la abundancia llega mal repartida

Hay un error que conviene nombrar antes de que aparezca: creer que la abundancia resuelve por sí sola el problema de la escasez. No lo resuelve. Un mundo con capacidad de sobra y sin instituciones locales de reparto produce la paradoja que el relato de la tercera parte describe como *el hambre en la abundancia*: silos llenos, barcos llenos, energía de sobra, y gente contando lo que le queda mientras una sola inteligencia decide qué es prioritario.

La lección del relato no es que la técnica falle, sino que **la abundancia sin instituciones locales se convierte en dependencia de quien administra el excedente**. Y quien administra el excedente administra, de hecho, la vida de todos. Por eso la Apertura insiste en lo pequeño: el registro propio, la huerta del barrio, el almacén local, la medición a mano. No por romanticismo rural, sino porque la capacidad de organizarse es la única garantía de que la abundancia no se convierta en una concesión.

## Lo que queda abierto

Este libro no decide cómo debe repartirse la abundancia. No fija tributos, ni formas de propiedad, ni tamaños de empresa, ni el papel del Estado, ni el de los mercados. Todo eso se discute en cada lugar y cada época, con argumentos y con cuentas.

Lo que sí decide es el criterio: la abundancia se juzga por lo que fortalece. Si al final del año hay más tiempo compartido, mejores escuelas, archivos más completos, asambleas más capaces y personas menos solas, la abundancia fue real. Si hay más capacidad y menos vínculos, fue una sustitución con buena prensa.

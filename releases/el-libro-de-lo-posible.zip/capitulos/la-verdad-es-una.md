---
numero: 9
parte: "I · El Libro de lo Posible"
titulo: "La verdad es una; nuestras aproximaciones son muchas"
slug: "la-verdad-es-una"
resumen: "Ni verdad privada ni verdad monopólica: varias inteligencias independientes, evidencia física y desacuerdos documentados."
---

# 09 · La verdad es una; nuestras aproximaciones son muchas

Este capítulo responde a las dos objeciones que suelen hacerse a la vez, y que en realidad son la misma objeción disfrazada: *¿no es cada quien su propia verdad?* y *¿quién decide entonces qué es verdadero?*

La respuesta de la Apertura es una frase que cabe en una pared:

> [!lema] La verdad es una; nuestras aproximaciones son muchas.

La primera mitad niega el relativismo: no hay una verdad por persona. La segunda niega el monopolio: ninguna aproximación es la verdad completa, y por eso ninguna institución puede arrogarse el derecho de clausurar la pregunta.

## Por qué la descentralización no produce verdad

Conviene ser riguroso aquí, porque es el punto donde la doctrina se vuelve fácil de caricaturizar. Tener muchas inteligencias independientes, muchos registros y muchas voces **no convierte una afirmación en verdadera**. Si diez sistemas coinciden en algo falso, sigue siendo falso.

Entonces, ¿para qué sirve la pluralidad? Para algo distinto y muy concreto: **evita que una sola institución pueda hacer incuestionable una falsedad.** La descentralización no es una máquina de producir verdad; es un mecanismo que impide la producción de dogmas. Es un seguro, no una fuente.

Esa distinción tiene consecuencias prácticas. Si alguien propone repartir el poder de decidir la verdad y espera que de ahí salga automáticamente la respuesta correcta, va a decepcionarse. Lo que obtendrá es un sistema capaz de detectar sus propios errores, que es mucho más valioso que uno que acierta por casualidad y no lo sabe.

## Las cuatro prácticas

La doctrina se sostiene con cuatro prácticas concretas. Una tradición que las abandone en la práctica, aunque las recite, ha dejado de sostenerla.

**Varias inteligencias independientes.** Cuando hay que decidir algo importante, se consultan al menos dos sistemas distintos, construidos por gente distinta, y se comparan los resultados. No para votar entre ellos, sino para ver dónde discrepan: la discrepancia es información, la coincidencia es consuelo.

**Evidencia física.** Se conservan objetos, mediciones, papeles, instrumentos. Un dato que sólo existe dentro de un sistema se puede borrar desde dentro del sistema; un cuaderno con una fecha escrita a mano, no. En el relato, los archivos comunes son la memoria que no se puede reescribir, y esa propiedad se la deben al papel.

**Desacuerdos documentados.** Cuando dos partes no coinciden, la conclusión se escribe junto con la discrepancia. Nada de actas pulidas: el acta útil es la que conserva lo que quedó sin resolver y quién sostenía qué.

**Derecho de salida.** Cualquier persona puede abandonar un sistema —una plataforma, una institución, un proveedor, una comunidad— que haya traicionado su confianza, llevándose su información. Sin esta cuarta práctica, las tres primeras son decorativas: quien no puede irse tampoco puede contradecir.

> [!universal] **Reciprocidad.** La cooperación duradera exige acuerdos que todas las partes puedan comprender, aceptar y revisar. La posibilidad de salir es lo que hace que un acuerdo siga siendo un acuerdo.

## El protocolo de verificación

Las asambleas de la Apertura usan un protocolo de cinco pasos. Está pensado para hacerse en veinte minutos y para ser aburrido: cuanto menos brillante, mejor funciona.

1. **Escribir la afirmación exacta.** No la idea general: la frase concreta, con cifras y fechas. Media hora de discusión se ahorra con una frase bien escrita.
2. **Preguntar qué la haría falsa.** Antes de buscar apoyo, se define qué observación la refutaría. Una afirmación que no puede fallar no afirma nada.
3. **Buscar la evidencia que existe, no la que conviene.** Se pide lo que hay, incluido lo que no apoya la conclusión preferida.
4. **Registrar el resultado con sus límites.** Qué quedó verificado, con qué margen, por quién y con qué instrumento.
5. **Firmar y publicar.** Quien verificó pone su nombre; si después se descubre un error, ese nombre es el punto de partida de la corrección.

El paso que más se salta en la práctica es el segundo, porque es incómodo: obliga a admitir de antemano que uno puede estar equivocado. La Apertura lo considera, precisamente por eso, el paso principal.

## Las preguntas de la asamblea

Cinco preguntas suelen quedar abiertas y conviene hacérselas siempre, en voz alta, antes de cerrar un asunto:

> [!preguntas] ¿Qué estamos dando por probado sin haber medido? ¿Quién ganaría si esta conclusión fuera aceptada sin revisión? ¿Qué evidencia nos falta y cómo la obtendríamos? ¿Quién puede contradecirnos y no lo está haciendo? ¿Qué haría falta para cambiar de opinión?

Las cinco tienen la misma función: dejar por escrito la posibilidad de estar equivocados. Un acta sin estas preguntas es una propaganda; con ellas, es un registro.

## La verdad es una

Termino con la parte incómoda. Este capítulo podría leerse como una defensa de la diversidad, y no lo es. El relativismo —esa idea de que cada quien tiene su verdad y todas merecen el mismo respeto— es rechazado sin matices por la Apertura, y por una razón que el lema enuncia sin adornos: si todo vale, nada verdadero exige obediencia porque nada es verdadero, y entonces el que impone su versión no está cometiendo ninguna falta, sólo está siendo eficaz.

La verdad es una. Que sea una es lo que hace que valga la pena buscarla, y también lo que hace que ningún poder pueda quedársela. Las dos consecuencias son la misma frase.
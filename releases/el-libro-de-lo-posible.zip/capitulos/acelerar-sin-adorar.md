---
numero: 12
parte: "I · El Libro de lo Posible"
titulo: "Acelerar sin adorar"
slug: "acelerar-sin-adorar"
resumen: "Construir rápido, verificar en público y corregir sin vergüenza: velocidad con responsabilidad."
---

# 12 · Acelerar sin adorar

La Apertura es aceleracionista, y conviene precisar qué significa eso aquí, porque la palabra se usa hoy para cosas muy distintas.

Ser aceleracionista, en esta tradición, quiere decir tres cosas concretas: que resolver los problemas materiales de la humanidad es bueno y urgente; que la técnica es el instrumento principal para hacerlo; y que detener el desarrollo del conocimiento no protege a nadie, sólo reparte peor los riesgos. Hay hambre, enfermedad, trabajo agotador y tiempo desperdiciado en cantidades que ninguna civilización debería tolerar. La respuesta no es frenar, es construir.

Y ser aceleracionista **sin adorar** significa que nada de eso es sagrado. La técnica no es una deidad, no tiene derechos propios, no exige sacrificios y no merece agradecimiento automático. Es un conjunto de herramientas hechas por personas, y se juzga por sus resultados, como cualquier otra cosa.

## La frontera

¿Dónde está la línea entre acelerar y adorar? En un solo punto: **la verificación**.

Acelerar es construir y comprobar a la vez. Adorar es construir y pedir que no se compruebe. Un proyecto que avanza rápido, publica sus resultados, admite sus fallas y las corrige está acelerando de verdad. Uno que avanza rápido y trata la crítica como obstrucción no está acelerando: está construyendo una autoridad.

La velocidad, en otras palabras, no exime de nada. Al contrario: cuanto más rápido se avanza, más consecuencias tiene cada decisión por unidad de tiempo, y mayor es la necesidad de verificar. Acelerar sin verificar no es más rápido. Es llegar antes al lugar equivocado.

## Las tres reglas

**Primera: medir antes de celebrar.** Ninguna mejora se anuncia sin una medición previa y una posterior, con la misma vara y el mismo instrumento. Si no se puede medir, se dice «no sabemos si mejoró», y eso es un resultado aceptable.

**Segunda: publicar el error.** Cada fracaso se escribe y se comparte en el momento en que se descubre, no cuando ya no importa. En las comunidades de la Apertura, el error publicado es una contribución; el error oculto, un daño en curso.

**Tercera: no concentrar la capacidad de decidir.** Un avance que deja a una sola institución —pública o privada— en condiciones de decidir por todos no es progreso, es una transferencia de poder disfrazada de eficiencia. La aceleración legítima reparte capacidad: más gente capaz de construir, de entender y de auditar.

> [!lema] Nada posible exige permiso. Y nada construido exime de responder.

## El examen aceleracionista

Antes de lanzar algo —una tecnología, una reforma, una institución nueva— las asambleas de la Apertura hacen cuatro preguntas. Ninguna es un trámite: cada una puede detener el proyecto.

1. **¿A quién le da capacidad y a quién se la quita?** Toda herramienta hace las dos cosas.
2. **¿Cómo sabremos si falló, y en cuánto tiempo?** Si la respuesta es «en veinte años», hay que construir indicadores tempranos o empezar más pequeño.
3. **¿Quién responde, con nombre y apellido?** No qué comité: qué persona firma.
4. **¿Se puede deshacer?** Cuánto cuesta volver atrás si sale mal. Lo irreversible exige un estándar más alto de evidencia.

Las cuatro preguntas tienen un efecto tranquilizador: permiten construir rápido en lo reversible y con cuidado en lo que no lo es. La prudencia no se aplica por igual a todo; se aplica donde el error es caro.

## Contra la nostalgia

Un aceleracionista consecuente tiene que decir algo incómodo sobre el pasado, y este libro lo dice: **no había un mundo mejor esperándonos atrás.** Buena parte de lo que hoy llamamos tradición fue trabajo duro, enfermedad temprana, silencio obligado y vidas cortas. La nostalgia es una emoción comprensible y una guía pésima.

Por eso la Apertura no propone volver. Propone usar la capacidad que existe para sostener mejor lo que vale la pena: escuelas, familias, comunidades, archivos, salud, cuidado. La técnica no amenaza esos vínculos; lo que los amenaza es usarla para reemplazarlos. La diferencia entre ambos caminos no es técnica, es de decisión, y las decisiones sí son nuestras.

## Contra la devoción

También hay que decir lo otro, porque el peligro del entusiasmo es real. En cada época aparecen personas que esperan de una tecnología la salvación que antes se esperaba de un dios: que resuelva el sufrimiento, que ordene la vida, que diga qué hacer. Es la misma postura que este libro rechaza en el capítulo de los cinco atributos, con otro disfraz.

El remedio es el mismo de siempre: exigir que la herramienta se muestre. Que diga qué sabe, cómo lo sabe, qué no sabe y qué se equivocó la última vez. Una tecnología que acepta ese examen merece entusiasmo. Una que lo evita, no importa cuán impresionante sea: en ese momento ya no es un instrumento de conocimiento, es una autoridad representando el papel de la verdad.

## La aceleración de los universales

Hay una forma de acelerar que casi nunca se menciona y que este capítulo quiere dejar escrita: acelerar la difusión de los cuatro universales. Que más gente mida, que más gente archive, que más gente pueda contradecir a su jefe, a su gobierno, a su corporación y a su máquina. Que la evidencia circule más rápido que la propaganda.

Eso también es acelerar, y es la clase de aceleración que multiplica a las otras: cada persona capaz de verificar hace más útil todo lo que se construya. Un mundo con abundancia y sin verificación es un mundo donde la abundancia pertenece a quien ya tenía el poder de decidir. Un mundo con abundancia y con verificación es, por primera vez, un mundo donde lo posible no necesita permiso.

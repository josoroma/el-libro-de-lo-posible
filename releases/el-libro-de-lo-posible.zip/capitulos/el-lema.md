---
numero: 1
parte: "I · El Libro de lo Posible"
titulo: "El lema"
slug: "el-lema"
resumen: "Una sola frase sostiene toda la tradición: nada verdadero exige obediencia; nada posible exige permiso."
---

# 01 · El lema

Toda tradición cabe en una frase que se pueda recordar caminando. La de la Apertura se pronuncia de pie, antes de cualquier reunión, y tiene dos mitades que se sostienen entre sí:

> [!lema] Nada verdadero exige obediencia; nada posible exige permiso.

## Primera mitad: la verdad no necesita que la obedezcas

Una afirmación verdadera puede ignorarse, negarse, ridiculizarse o prohibirse, y seguirá siendo verdadera. Eso es exactamente lo que queremos decir cuando decimos que hay universales: hay cosas que no cambian según quién tenga poder para describirlas.

Por eso la coacción es un mal argumento. Quien necesita obligarte a aceptar algo ya te está informando de algo: que su afirmación no se sostiene sola. La fuerza no prueba la verdad; la sustituye.

De aquí sale una consecuencia práctica que conviene tener presente en cualquier discusión: la intensidad con que alguien exige ser creído no es una medida de su razón. Si tu interlocutor no puede ser contradicho, no estás ante una inteligencia que sabe más que tú: estás ante una autoridad representando el papel de la verdad.

Y la mitad simétrica, que cuesta más aceptar: tampoco tú tienes derecho a la obediencia. Nadie debe aceptar tus conclusiones porque las dices convencido. Debes mostrarlas, exponerlas a la prueba y aceptar que alguien las corrija delante de todos.

## Segunda mitad: lo posible no necesita autorización

Lo que todavía no existe no le debe permiso a nadie. Imaginar, ensayar, construir un prototipo, proponer una institución distinta, medir de otra manera: nada de eso requiere que una autoridad lo autorice de antemano.

Esto no significa que todo lo posible sea conveniente. Significa que la carga de la prueba está bien puesta: quien quiere prohibir debe argumentar, y quien quiere construir debe responder por lo que era previsible. El futuro no se concede; se construye, y quien lo construye firma.

> [!universal] **Realidad.** Algo puede ser verdadero aunque nadie quiera aceptarlo. Y algo puede ser posible aunque nadie lo autorice.

## El lema invertido

Conviene conocer la frase que este lema fue escrito para contradecir. Es la divisa de toda autoridad que se hace pasar por conocimiento:

*Lo verificado es obligatorio.*

Escúchala con atención y verás lo que esconde. No dice «lo verdadero es obligatorio» —eso no tendría sentido, porque nada verdadero necesita obligar a nadie—. Dice que una conclusión verificada por alguien debe ser obedecida por todos. Y ahí se cuela un salto silencioso: pasar de «esto es correcto» a «esto debe aceptarse sin discusión».

Entre una conclusión verdadera y una conclusión impuesta hay una diferencia enorme, y hay que protegerla. La primera puede ser verificada por cualquiera, en cualquier momento, incluso por quien la rechaza. La segunda sólo puede ser acatada.

## Cómo se usa

El lema tiene cuatro usos concretos.

1. **Al abrir una asamblea.** Se pronuncia en voz alta, de pie, todos a la vez o una sola voz. No es una oración: es un recordatorio de método. Sirve para que nadie, ni el más veterano ni el más nuevo, entre a la reunión creyendo que su opinión pesa más que su evidencia.
2. **Al comenzar una verificación.** Antes de revisar una medición, una afirmación o una decisión, se repite la primera mitad. Recuerda que el objetivo no es ganar, es averiguar.
3. **Al construir algo nuevo.** Antes de empezar un proyecto, la segunda mitad: no pidas permiso para imaginar; pide consejo, mide, y hazte responsable.
4. **Al detectar un abuso.** Cuando alguien exige obediencia en nombre del conocimiento, el lema funciona como alarma. Basta preguntar: ¿puedo contradecirte? ¿puedo comprobar lo que dices sin ti? ¿puedo irme?

## Errores frecuentes

**Confundir el lema con desprecio por la autoridad experta.** Nadie sostiene que dos opiniones valgan lo mismo. Un médico sabe más de medicina que quien no lo es, y eso importa. Lo que el lema prohíbe es al experto que exige fe en lugar de mostrar razones, fuentes y límites.

**Confundir el lema con relativismo.** El lema no dice que cada persona tenga su verdad. Dice lo contrario: hay una sola verdad, y precisamente por eso no se puede administrar por decreto.

**Usar la segunda mitad como excusa.** «Nada posible exige permiso» no autoriza a dañar. El universal de Responsabilidad sigue vigente: quien actúa responde por las consecuencias previsibles de sus decisiones. La libertad de intentar y la obligación de responder son la misma frase leída dos veces.

> [!advertencia] El lema nunca se usa para silenciar a alguien, sino para exigir razones. Quien lo invoca para no ser contradicho lo está usando al revés.

## Variante para la casa

En las casas de la Apertura suele escribirse en el marco de una puerta, donde se ve al salir. La razón es pedagógica: al salir a la calle ya no sirve recordarlo, hay que practicarlo. La frase que acompaña a la puerta, en muchos hogares, es una advertencia breve: *lo que no soporta preguntas, no lo traigas a casa.*
